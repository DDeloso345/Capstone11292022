﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class ShelfListCardPreview : Form
    {
        public ShelfListCardPreview()
        {
            InitializeComponent();
        }
    }
}
