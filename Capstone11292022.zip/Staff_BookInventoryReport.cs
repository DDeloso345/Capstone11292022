﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Staff_Book_Inventory_Report : Form
    {
        public Staff_Book_Inventory_Report()
        {
            InitializeComponent();
        }
    }
}
