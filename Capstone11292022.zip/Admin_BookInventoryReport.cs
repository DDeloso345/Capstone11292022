﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Admin_BookInventoryReport : Form
    {
        public Admin_BookInventoryReport()
        {
            InitializeComponent();
        }

        private void Admin_BookInventoryReport_Load(object sender, System.EventArgs e)
        {

        }
    }
}
