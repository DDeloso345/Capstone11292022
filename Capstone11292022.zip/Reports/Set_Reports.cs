﻿namespace Capstone.Reports
{


    partial class Set_Reports
    {
    }
}
