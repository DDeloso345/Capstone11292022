﻿namespace Capstone.Reports.MemberBorrowedBooks.Tabular_Narrative
{


    partial class MBB_Set_Tabular_Narrative
    {
    }
}
