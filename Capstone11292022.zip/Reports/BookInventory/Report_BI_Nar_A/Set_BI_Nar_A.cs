﻿namespace Capstone.Reports.BookInventory.Report_BI_Nar_A
{
}