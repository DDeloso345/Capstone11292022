﻿namespace Capstone.Reports.BookInventory.Report_BI_Tab_A
{


    partial class Set_BI_Tab_A
    {
    }
}
