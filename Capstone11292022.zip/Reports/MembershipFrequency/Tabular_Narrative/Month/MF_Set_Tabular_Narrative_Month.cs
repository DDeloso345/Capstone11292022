﻿namespace Capstone.Reports.MembershipFrequency.Tabular_Narrative.Month
{


    partial class MF_Set_Tabular_Narrative_Month
    {
    }
}
