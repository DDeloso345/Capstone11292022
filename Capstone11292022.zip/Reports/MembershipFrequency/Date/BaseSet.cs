﻿namespace Capstone.Reports.MembershipFrequency.Date
{


    partial class BaseSet
    {
    }
}
