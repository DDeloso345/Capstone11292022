﻿namespace Capstone.Reports.MembershipFrequency.Graph.Year
{


    partial class MF_Set_Graph_Year
    {
    }
}
