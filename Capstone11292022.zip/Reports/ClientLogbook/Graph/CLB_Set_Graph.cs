﻿namespace Capstone.Reports.ClientLogbook.Graph
{


    partial class CLB_Set_Graph
    {
    }
}
