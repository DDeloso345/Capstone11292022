﻿using System;

namespace Capstone
{
    public class ClientWalkInLogbookInfo
    {
        public String id {get; set;}
        public String FirstName {get; set;}
        public String MiddleName {get; set;}
        public String LastName {get; set;}
        public String Address {get; set;}
        public String ContactNo {get; set;}
        public String Date {get; set;}
        public String Time {get; set;}
    }
    public class getLogbookColumns {
        public String name {get; set;}
}
}
