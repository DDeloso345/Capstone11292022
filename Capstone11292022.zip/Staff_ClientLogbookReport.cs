﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Staff_ClientLogbookReport : Form
    {
        public Staff_ClientLogbookReport()
        {
            InitializeComponent();
        }
    }
}
