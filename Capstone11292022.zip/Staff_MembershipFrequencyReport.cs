﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Staff_MembershipFrequencyReport : Form
    {
        public Staff_MembershipFrequencyReport()
        {
            InitializeComponent();
        }
    }
}
