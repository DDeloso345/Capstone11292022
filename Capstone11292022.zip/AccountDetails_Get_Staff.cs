﻿using System;

namespace Capstone
{
    public class AccountDetails_Get_Staff
    {
        public int id { get; set; }
        public String FirstName { get; set; }
        public String MiddleName { get; set; }
        public String LastName { get; set; }
        public String Suffix { get; set; }
        public String Position { get; set; }
        public String EmpRoles { get; set; }
        public String EmailAddress { get; set; }
        public String ContactNo { get; set; }
        public String Username { get; set; }
        public String ImgPath { get; set; }
    }
}
