﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Admin_MembershipFrequencyReport : Form
    {
        public Admin_MembershipFrequencyReport()
        {
            InitializeComponent();
        }
    }
}
